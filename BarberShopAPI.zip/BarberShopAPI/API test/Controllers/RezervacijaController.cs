﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APItest.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using APItest.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace API_test.Controllers
{
    [Route("api/rezervacija")]
    [ApiController]
    public class RezervacijaController : ControllerBase
    {
        private readonly MojContex _context;
        private int sati = (DateTime.UtcNow.Hour) + 1;
     
        public RezervacijaController(MojContex db)
        {
            _context = db;
        }
            
        [HttpGet ("{id}")]
        public ActionResult<IEnumerable<RezervacijeVM>> VratiMojeRezervazije(int id)
        {
            if (sati == 24)
                sati = 0;
            var rezerv= _context.RezervacijeT.Where(x => x.UserID == id).Include(x=>x.Termin).ToList();
            List<RezervacijeT> Rezer = new List<RezervacijeT>();

            for (int i = 0; i < rezerv.Count; i++)
            {
                string datumRezerv = rezerv[i].dan.ToString() + "." + rezerv[i].mjesec.ToString() + "." + rezerv[i].godina.ToString();
                DateTime datumRezervacije = DateTime.Parse(datumRezerv);

                if (datumRezervacije > DateTime.Today)
                         Rezer.Add(rezerv[i]);
                if (datumRezervacije==DateTime.Today && rezerv[i].Termin.Vrijeme.Hour>sati)
                         Rezer.Add(rezerv[i]);
                
            }

            List<RezervacijeVM> lista = new List<RezervacijeVM>();
            for (int i = 0; i < Rezer.Count; i++)
            {
                RezervacijeVM rez = new RezervacijeVM();
                rez.id = Rezer[i].Id;
                rez.dan = Rezer[i].dan;
                rez.mjesec = Rezer[i].mjesec;
                rez.godina = Rezer[i].godina;
                rez.terminid = Rezer[i].TerminID;
                rez.termin = Rezer[i].Termin.Termin;

                lista.Add(rez);
            }
            if (lista.Count == 0)
            {
                return null;
            }
            return lista;
        }

        [HttpGet("{dan}/{mjesec}/{godina}")]
        public ActionResult<IEnumerable<Termini>> VratiTermine(int dan, int mjesec, int godina)
        {
            if (sati == 24)
                sati = 0;
            List<Termini> Slobodni = _context.Termini.ToList();
            List<RezervacijeT> rezervacije = _context.RezervacijeT.Where(x=>x.dan==dan && x.mjesec==mjesec && x.godina == godina).ToList();

            List<Termini> SlobodniRez = new List<Termini>();
            if (dan == DateTime.Today.Day && mjesec == DateTime.Today.Month && godina == DateTime.Today.Year)
            {         
            SlobodniRez = Slobodni.Where(x => x.Vrijeme.Hour > sati).ToList();}
            else
            {SlobodniRez = Slobodni;}
            foreach (var item in rezervacije)
            {
                var rez = SlobodniRez.Where(x =>x.Id == item.TerminID).FirstOrDefault();
                if (rez != null)
                    SlobodniRez.Remove(rez);
            }

            if (SlobodniRez.Count==0)
            {
                return null;
            }
            return SlobodniRez;
        }

        [HttpPost]
        public async Task<ActionResult<RezervacijeT>> SpremiRezervaciju(RezervacijeT rez)
        {
            var nadjen =_context.RezervacijeT.Where(x=>x.UserID==rez.UserID && rez.dan == x.dan && rez.mjesec == x.mjesec && rez.godina == x.godina).FirstOrDefault();

            if (nadjen != null)
            {
                return null;
            }
            else
            {
                rez.DatumRezervacije = DateTime.Now;
                _context.RezervacijeT.Add(rez);
                await _context.SaveChangesAsync();
                return rez;
            }
          



        }

        [HttpDelete("{id}")]
        public StatusCodeResult Delete(int id)
        {
            var rezv = _context.RezervacijeT.Find(id);
            _context.RezervacijeT.Remove(rezv);
            _context.SaveChanges();

            return new OkResult(); 
        }

    }
}