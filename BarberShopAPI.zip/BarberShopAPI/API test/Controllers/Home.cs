﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using APItest.Models;

namespace API_test.Controllers
{
    public class Home : Controller
    {
        

        // GET: Home
        public  IActionResult Index()
        {
            return View();
        }

        public FileResult Download()
        {
            var fileName = $"app-release.apk";
            var filepath = $"{fileName}";
            byte[] fileBytes = System.IO.File.ReadAllBytes(filepath);
            return File(fileBytes, "application/x-msdownload", fileName);
        }


    }
}
