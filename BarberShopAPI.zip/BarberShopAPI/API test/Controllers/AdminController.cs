﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APItest.Models;
using APItest.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API_test.Controllers
{
    [Route("api/admin")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly MojContex _context;
        public AdminController(MojContex db)
        {
            _context = db;
        }


        [HttpGet("{d}/{m}/{g}")]
        public ActionResult<IEnumerable<RezervacijeFull>> VratiSve(int d,int m, int g)
        {
            List<RezervacijeT> rezervacije = _context.RezervacijeT.Where(x => x.dan == d && x.mjesec == m && x.godina == g).Include(x=>x.Termin).Include(x=>x.User).ToList();
            List<RezervacijeFull> rez = new List<RezervacijeFull>();
            for (int i = 0; i < rezervacije.Count; i++)
            {
                RezervacijeFull one = new RezervacijeFull();
               
                one.termin = rezervacije[i].Termin.Termin;
                one.klijent = rezervacije[i].User.Name;
                one.brojt = rezervacije[i].User.BrojTelefona;
                rez.Add(one);
            }
            if (rez.Count == 0)
            {
                return null;
            }

            return rez;
        }
    }
}