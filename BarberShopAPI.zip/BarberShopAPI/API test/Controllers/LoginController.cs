﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APItest.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace API_test.Controllers
{
    [Route("api/login")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private MojContex _context;
        public LoginController(MojContex ctx)
        {
            _context = ctx;
        }


      
    
        [HttpPost]
        public async Task<ActionResult<TodoItem>> GetBrojTefona(TodoItem item1)
        {
            if (item1.Name != null)
            {
                _context.TodoItems.Add(item1);
                 await _context.SaveChangesAsync();
                return item1;
            }
            else {
                TodoItem user = _context.TodoItems.Where(i => i.BrojTelefona == item1.BrojTelefona && i.Password == item1.Password).FirstOrDefault();
                if (user != null)
                {
                    return user;

                }
                else
                {
                    return Unauthorized();
                }
            }

           


        }
        [HttpGet("{id}")]
        public async Task<ActionResult<TodoItem>> GetTodoItem(long id)
        {
            var todoItem = await _context.TodoItems.FindAsync(id);

            if (todoItem == null)
            {
                return NotFound();
            }

            return todoItem;
        }

       
        [HttpPut("{id}")]
        public async Task<ActionResult<TodoItem>> EditPodataka(long id,[FromBody] TodoItem item)
        {
            if (id != item.Id)
            {
                return NotFound();
            }

            _context.Entry(item).State = EntityState.Modified;
             await _context.SaveChangesAsync();

            return item;
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTodoItem(long id)
        {
            var todoItem = await _context.TodoItems.FindAsync(id);

            if (todoItem == null)
            {
                return NotFound();
            }

            _context.TodoItems.Remove(todoItem);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}