﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APItest.Models
{
    public class MojContex:DbContext
{
        public MojContex(DbContextOptions<MojContex> options)
           : base(options)
        {
        }

        public DbSet<TodoItem> TodoItems { get; set; }
        public DbSet<RezervacijeT> RezervacijeT { get; set; }
        public DbSet<Termini> Termini { get; set; }

    }
}
