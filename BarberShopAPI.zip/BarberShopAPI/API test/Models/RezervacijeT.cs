﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using APItest.Models;

namespace APItest.Models
{
    public class RezervacijeT
{
        public int Id { get; set; }
        public DateTime DatumRezervacije { get; set; }

        [ForeignKey("UserID")]
        public long UserID { get; set; }
        public TodoItem User { get; set; }
        [ForeignKey("TerminID")]
        public int TerminID { get; set; }
        public Termini Termin { get; set; }

        public int dan { get; set; }
        public int mjesec { get; set; }
        public int godina { get; set; }


    }
}
