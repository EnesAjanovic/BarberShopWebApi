﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APItest.Models
{
    public class Termini
{
    public int Id { get; set; }
        public string Termin { get; set; }

        public DateTime Vrijeme { get; set; }

}
}
