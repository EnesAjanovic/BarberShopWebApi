﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APItest.ViewModel
{
    public class RezervacijeVM
{
       public int id { get; set; }
        public int dan { get; set; }
        public int mjesec { get; set; }
        public int godina { get; set; }
        public int terminid { get; set; }
        public string termin { get; set; }

    }
}
