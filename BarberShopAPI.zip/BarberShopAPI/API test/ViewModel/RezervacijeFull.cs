﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APItest.ViewModel
{
    public class RezervacijeFull
{
    
    public string termin { get; set; }
        public string klijent { get; set; }
        public string brojt { get; set; }
}
}
