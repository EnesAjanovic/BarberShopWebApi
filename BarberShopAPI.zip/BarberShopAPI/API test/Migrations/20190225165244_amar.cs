﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace APItest.Migrations
{
    public partial class amar : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "dan",
                table: "RezervacijeT",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "godina",
                table: "RezervacijeT",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "mjesec",
                table: "RezervacijeT",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "dan",
                table: "RezervacijeT");

            migrationBuilder.DropColumn(
                name: "godina",
                table: "RezervacijeT");

            migrationBuilder.DropColumn(
                name: "mjesec",
                table: "RezervacijeT");
        }
    }
}
