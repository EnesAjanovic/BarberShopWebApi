﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace APItest.Migrations
{
    public partial class kins : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "TerminID",
                table: "RezervacijeT",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Termini",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Termin = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Termini", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_RezervacijeT_TerminID",
                table: "RezervacijeT",
                column: "TerminID");

            migrationBuilder.AddForeignKey(
                name: "FK_RezervacijeT_Termini_TerminID",
                table: "RezervacijeT",
                column: "TerminID",
                principalTable: "Termini",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RezervacijeT_Termini_TerminID",
                table: "RezervacijeT");

            migrationBuilder.DropTable(
                name: "Termini");

            migrationBuilder.DropIndex(
                name: "IX_RezervacijeT_TerminID",
                table: "RezervacijeT");

            migrationBuilder.DropColumn(
                name: "TerminID",
                table: "RezervacijeT");
        }
    }
}
